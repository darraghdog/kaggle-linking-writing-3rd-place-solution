"""Define the task to solve its loss, metric."""

from .base import Task


__all__ = ["losses", "base", "common_metric", "utils", "Task"]
