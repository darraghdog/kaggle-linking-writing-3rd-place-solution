"""Common util tools."""

__all__ = ["timer"]
